<?php
$_SESSION['GUEST']=array("FORBID"=>array("student/delete"));
?>