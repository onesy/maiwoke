<?php
define('DefaultLink',"localhost,root,");//默认链接，以逗分分拆
define('MyLink',"localhost,pma,");
//UTF8编码
?>