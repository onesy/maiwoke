<?php
define('SmartyInitFile','../smarty/Smarty.class.php');
define('TemplateDir',"V/");
define('CompileDir',"Public/templates_c/");
define('LeftDelimiter','<%');
define('RightDelimiter','%>');
define('TplExtension','.html');
?>