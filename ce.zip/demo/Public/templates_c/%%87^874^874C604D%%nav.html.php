<?php /* Smarty version 2.6.25, created on 2010-10-05 07:00:07
         compiled from include/nav.html */ ?>
    <div class="color1" style="width:100%">
        <div style="background:#EBEBEB">  
			<div id="navcontainer">
			<ul id="navlist">
			<li><a href="<?php echo $this->_tpl_vars['WebRoot']; ?>
/">首页</a></li>
			<li><a href="<?php echo $this->_tpl_vars['WebRoot']; ?>
/demo/show">综合演示</a></li>
			<li><a href="<?php echo $this->_tpl_vars['WebRoot']; ?>
/demo/crud">CRUD演示</a></li>
			<li><a href="<?php echo $this->_tpl_vars['WebRoot']; ?>
/rbac">RBAC演示</a></li>
			<li><a href="<?php echo $this->_tpl_vars['WebRoot']; ?>
/ajax/show">AJAX分页</a></li>
			</ul>
			</div>
        </div>
  
    </div>