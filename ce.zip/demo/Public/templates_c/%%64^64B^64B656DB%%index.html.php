<?php /* Smarty version 2.6.16, created on 2010-03-25 12:36:02
         compiled from student/index.html */ ?>
