<?php /* Smarty version 2.6.25, created on 2010-05-26 06:53:31
         compiled from include/bottom.html */ ?>
<div id="bottom">
  CEPHP： A concise and easy freamwork for PHP <br />



</div>