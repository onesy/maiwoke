<?php /* Smarty version 2.6.25, created on 2011-06-05 05:45:59
         compiled from index/index.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo $this->_tpl_vars['WebRoot']; ?>
/Public/Css/CE.css" />
<title>CEphp框架，PHP超轻量级框架</title>
</head>
<body>

<div id="body">
<div align="left"><img src="<?php echo $this->_tpl_vars['WebRoot']; ?>
/Public/Img/CEPHP.png"  /></div>



	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "include/nav.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
  


<div align="left" style="padding:20px">
<h5>框架配置及各模块布局：</h5><br>
<ul>
  <li>为保持根目录清晰，建议将模板与框架目录（Cemvc）放在与根目录平行的位置。</li>
  <li>初始化文件请参考根目录index.php。</li>
  <li>根目录M，V，C分别对应模型，视图，控制器文件夹。</li>
  <li>框架完美支持SMARTY模板。</li>
</ul>
<h5>框架运行环境：</h5>
<br>
<ul>
  <li>CEPHP支持WIN系列和LINUX或UNIX等OS平台。</li>
  <li>PHP版本要求不低于5.0,最高测试版本为php 5.3。</li>
  </ul>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>
</div>
  <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "include/bottom.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>  
</p>
</div>
</body>
</html>